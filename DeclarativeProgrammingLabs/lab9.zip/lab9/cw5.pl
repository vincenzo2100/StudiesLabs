% liczba_elem1(+L,?N) - wersja naiwna
% spe�niony, gdy N jest liczb� element�w listy L
% -----------------------------------------------

% warunek ko�cz�cy rekurencj�: lista pusta ma
% zero element�w

liczba_elem1([],0).

% rekurencja: liczba element�w listy L jest r�wna
% d�ugo�ci ogona tej listy plus 1

liczba_elem1([_|T],N):-
    liczba_elem1(T,N1),
    N is N1+1.
/*
[trace]  ?- liczba_elem1([1,2,3,4,5,6,7],N).
   Call: (10) liczba_elem1([1, 2, 3, 4, 5, 6, 7], _13996) ? creep
   Call: (11) liczba_elem1([2, 3, 4, 5, 6, 7], _15286) ? creep
   Call: (12) liczba_elem1([3, 4, 5, 6, 7], _16042) ? creep
   Call: (13) liczba_elem1([4, 5, 6, 7], _16798) ? creep
   Call: (14) liczba_elem1([5, 6, 7], _17554) ? creep
   Call: (15) liczba_elem1([6, 7], _18310) ? creep
   Call: (16) liczba_elem1([7], _19066) ? creep
   Call: (17) liczba_elem1([], _19822) ? creep
   Exit: (17) liczba_elem1([], 0) ? creep
   Call: (17) _19066 is 0+1 ? creep
   Exit: (17) 1 is 0+1 ? creep
   Exit: (16) liczba_elem1([7], 1) ? creep
   Call: (16) _18310 is 1+1 ? creep
   Exit: (16) 2 is 1+1 ? creep
   Exit: (15) liczba_elem1([6, 7], 2) ? creep
   Call: (15) _17554 is 2+1 ? creep
   Exit: (15) 3 is 2+1 ? creep
   Exit: (14) liczba_elem1([5, 6, 7], 3) ? creep
   Call: (14) _16798 is 3+1 ? creep
   Exit: (14) 4 is 3+1 ? creep
   Exit: (13) liczba_elem1([4, 5, 6, 7], 4) ? creep
   Call: (13) _16042 is 4+1 ? creep
   Exit: (13) 5 is 4+1 ? creep
   Exit: (12) liczba_elem1([3, 4, 5, 6, 7], 5) ? creep
   Call: (12) _114 is 5+1 ? creep
   Exit: (12) 6 is 5+1 ? creep
   Exit: (11) liczba_elem1([2, 3, 4, 5, 6, 7], 6) ? creep
   Call: (11) _18 is 6+1 ? creep
   Exit: (11) 7 is 6+1 ? creep
   Exit: (10) liczba_elem1([1, 2, 3, 4, 5, 6, 7], 7) ? creep
N = 7.
*/
