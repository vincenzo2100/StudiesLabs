using System;
using System.Threading;

class ForestFireSimulation
{
    private enum CellState
    {
        Empty,
        Tree,
        Burning,
        Burned
    }

    private readonly int _width;
    private readonly int _height;
    private readonly CellState[,] _grid;
    private readonly Random _random;
    private readonly double _burnProbability;

    public ForestFireSimulation(int width, int height, double burnProbability)
    {
        _width = width;
        _height = height;
        _grid = new CellState[_width, _height];
        _random = new Random();
        _burnProbability = burnProbability;
        InitializeForest();
    }

    private void InitializeForest()
    {
        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                _grid[x, y] = _random.NextDouble() < 0.7 ? CellState.Tree : CellState.Empty;
            }
        }
        // Start fire in a random tree cell
        while (true)
        {
            int startX = _random.Next(_width);
            int startY = _random.Next(_height);
            if (_grid[startX, startY] == CellState.Tree)
            {
                _grid[startX, startY] = CellState.Burning;
                break;
            }
        }
    }

    private void DisplayForest()
    {
        Console.Clear();
        for (int y = 0; y < _height; y++)
        {
            for (int x = 0; x < _width; x++)
            {
                Console.Write(GetCellSymbol(_grid[x, y]));
            }
            Console.WriteLine();
        }
    }

    private char GetCellSymbol(CellState state)
    {
        return state switch
        {
            CellState.Empty => '.',
            CellState.Tree => 'T',
            CellState.Burning => '*',
            CellState.Burned => ' ',
            _ => ' '
        };
    }

    public void RunSimulation()
    {
        while (true)
        {
            DisplayForest();
            if (!Step()) break;
            Thread.Sleep(500);
        }
        Console.WriteLine("Simulation finished.");
    }

    private bool Step()
    {
        bool fireExists = false;
        var newGrid = (CellState[,])_grid.Clone();

        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                if (_grid[x, y] == CellState.Burning)
                {
                    newGrid[x, y] = CellState.Burned;
                }
                else if (_grid[x, y] == CellState.Tree && HasBurningNeighbor(x, y))
                {
                    if (_random.NextDouble() < _burnProbability)
                    {
                        newGrid[x, y] = CellState.Burning;
                        fireExists = true;
                    }
                }
                else if (_grid[x, y] == CellState.Burning)
                {
                    fireExists = true;
                }
            }
        }

        Array.Copy(newGrid, _grid, _grid.Length);
        return fireExists;
    }

    private bool HasBurningNeighbor(int x, int y)
    {
        int[] dx = { -1, 0, 1, 0 };
        int[] dy = { 0, -1, 0, 1 };

        for (int i = 0; i < 4; i++)
        {
            int nx = x + dx[i];
            int ny = y + dy[i];

            if (nx >= 0 && nx < _width && ny >= 0 && ny < _height)
            {
                if (_grid[nx, ny] == CellState.Burning)
                {
                    return true;
                }
            }
        }
        return false;
    }

    public static void Main()
    {
        var simulation = new ForestFireSimulation(60, 30, 0.9);
        simulation.RunSimulation();
    }
}
