using System;
using System.Threading;

class ForestFireSimulation
{
    private enum CellState
    {
        Empty,
        Tree,
        Burning,
        Burned,
        Water
    }

    private enum WindDirection
    {
        None,
        North,
        South,
        East,
        West
    }

    private readonly int _width;
    private readonly int _height;
    private readonly CellState[,] _grid;
    private readonly int[,] _burnCounters;
    private readonly Random _random;
    private readonly double _burnProbability;
    private readonly double _spontaneousCombustionProbability;
    private readonly int _regenerationTime;
    private WindDirection _windDirection;

    public ForestFireSimulation(int width, int height, double burnProbability, double spontaneousCombustionProbability, int regenerationTime)
    {
        _width = width;
        _height = height;
        _grid = new CellState[_width, _height];
        _burnCounters = new int[_width, _height];
        _random = new Random();
        _burnProbability = burnProbability;
        _spontaneousCombustionProbability = spontaneousCombustionProbability;
        _regenerationTime = regenerationTime;
        _windDirection = WindDirection.None;
        InitializeForest();
    }

    private void InitializeForest()
    {
        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                double rand = _random.NextDouble();
                if (rand < 0.6)
                    _grid[x, y] = CellState.Tree;
                else if (rand < 0.8)
                    _grid[x, y] = CellState.Water;
                else
                    _grid[x, y] = CellState.Empty;
            }
        }

        StartFire();
    }

    private void StartFire()
    {
        while (true)
        {
            int startX = _random.Next(_width);
            int startY = _random.Next(_height);
            if (_grid[startX, startY] == CellState.Tree)
            {
                _grid[startX, startY] = CellState.Burning;
                break;
            }
        }
    }

    private void DisplayForest()
    {
        Console.Clear();
        for (int y = 0; y < _height; y++)
        {
            for (int x = 0; x < _width; x++)
            {
                Console.Write(GetCellSymbol(_grid[x, y]));
            }
            Console.WriteLine();
        }
    }

    private char GetCellSymbol(CellState state)
    {
        return state switch
        {
            CellState.Empty => '.',
            CellState.Tree => 'T',
            CellState.Burning => '*',
            CellState.Burned => ' ',
            CellState.Water => '~',
            _ => ' '
        };
    }

    public void RunSimulation()
    {
        while (true)
        {
            DisplayForest();
            if (!Step()) break;
            Thread.Sleep(500);
        }
        Console.WriteLine("Simulation finished.");
    }

    private bool Step()
    {
        bool fireExists = false;
        var newGrid = (CellState[,])_grid.Clone();

        for (int x = 0; x < _width; x++)
        {
            for (int y = 0; y < _height; y++)
            {
                switch (_grid[x, y])
                {
                    case CellState.Burning:
                        newGrid[x, y] = CellState.Burned;
                        break;

                    case CellState.Tree:
                        if (HasBurningNeighbor(x, y) && _random.NextDouble() < GetBurnProbability(x, y))
                        {
                            newGrid[x, y] = CellState.Burning;
                            fireExists = true;
                        }
                        else if (_random.NextDouble() < _spontaneousCombustionProbability)
                        {
                            newGrid[x, y] = CellState.Burning;
                            fireExists = true;
                        }
                        break;

                    case CellState.Burned:
                        _burnCounters[x, y]++;
                        if (_burnCounters[x, y] >= _regenerationTime)
                        {
                            newGrid[x, y] = CellState.Tree;
                            _burnCounters[x, y] = 0;
                        }
                        break;
                }
            }
        }

        Array.Copy(newGrid, _grid, _grid.Length);
        UpdateWindDirection();
        return fireExists;
    }

    private bool HasBurningNeighbor(int x, int y)
    {
        int[] dx = { -1, 0, 1, 0 };
        int[] dy = { 0, -1, 0, 1 };

        for (int i = 0; i < 4; i++)
        {
            int nx = x + dx[i];
            int ny = y + dy[i];

            if (nx >= 0 && nx < _width && ny >= 0 && ny < _height)
            {
                if (_grid[nx, ny] == CellState.Burning)
                {
                    return true;
                }
            }
        }
        return false;
    }

    private double GetBurnProbability(int x, int y)
    {
        return _windDirection switch
        {
            WindDirection.North when y > 0 && _grid[x, y - 1] == CellState.Burning => _burnProbability * 1.5,
            WindDirection.South when y < _height - 1 && _grid[x, y + 1] == CellState.Burning => _burnProbability * 1.5,
            WindDirection.East when x < _width - 1 && _grid[x + 1, y] == CellState.Burning => _burnProbability * 1.5,
            WindDirection.West when x > 0 && _grid[x - 1, y] == CellState.Burning => _burnProbability * 1.5,
            _ => _burnProbability
        };
    }

    private void UpdateWindDirection()
    {
        if (_random.Next(5) == 0)
        {
            _windDirection = (WindDirection)_random.Next(5);
        }
    }

    public static void Main()
    {
        var simulation = new ForestFireSimulation(20, 10, 0.3, 0.01, 5);
        simulation.RunSimulation();
    }
}
