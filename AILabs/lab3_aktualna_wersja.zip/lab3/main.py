from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt
import numpy as np

# ZAD 1.3

# dane wejściowe
rok = np.array([2000, 2002, 2005, 2007, 2010]).reshape((-1, 1))
bezrobocie = np.array([6.5, 7.0, 7.4, 8.2, 9.0])

# tworzenie i trenowanie modelu
model = LinearRegression().fit(rok, bezrobocie)

# wyznaczenie przewidywanych wartości dla lat 2000-2030
lata = np.arange(2000, 2031).reshape((-1, 1))
przewidywane_bezrobocie = model.predict(lata)

# wizualizacja danych
plt.scatter(rok, bezrobocie, color="red")
plt.scatter(lata, przewidywane_bezrobocie)
plt.plot(lata, przewidywane_bezrobocie, color="blue")
for i, txt in enumerate(bezrobocie):
    plt.annotate(
        "%.2f%%" % txt,
        (rok[i], bezrobocie[i]),
        textcoords="offset points",
        xytext=(0, 100),
        ha="center",
        color="red",
    )
    for i, txt in enumerate(przewidywane_bezrobocie):
        plt.annotate(
            "%.3f%%" % txt,
            (lata[i], przewidywane_bezrobocie[i]),
            textcoords="offset points",
            xytext=(0, -20),
            ha="center",
            color="blue",
        )
plt.axhline(12)
plt.xticks(np.arange(2000, 2031, 1))
plt.title("Procent bezrobocia w latach 2000-2030")
plt.xlabel("Rok")
plt.ylabel("Procent bezrobocia")
plt.show()

# ZAD 2.4
# ZAD 1


def perceptron_learn(input_data, output_data, learning_rate, num_epochs):
    num_inputs = input_data.shape[1]
    weights = np.zeros(num_inputs)
    bias = 0.0
    for epoch in range(num_epochs):
        for i in range(input_data.shape[0]):
            input_vector = input_data[i]
            predicted_output = np.dot(input_vector, weights) + bias
            if predicted_output > 0:
                predicted_output = 1
            else:
                predicted_output = 0
            error = output_data[i] - predicted_output
            weights += learning_rate * error * input_vector
            bias += learning_rate * error
    return weights, bias


# ZAD 2 na kartce
# ZAD 3 na kartce


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


def sigmoid_derivative(x):
    return x * (1 - x)


# ZAD 4
def backpropagation_algorithm_xor(input_data, output_data, learning_rate, num_epochs):
    inputLayerNeurons, hiddenLayerNeurons, outputLayerNeurons = 2, 2, 1
    hidden_weights = np.random.uniform(size=(inputLayerNeurons, hiddenLayerNeurons))
    hidden_bias = np.random.uniform(size=(1, hiddenLayerNeurons))
    output_weights = np.random.uniform(size=(hiddenLayerNeurons, outputLayerNeurons))
    output_bias = np.random.uniform(size=(1, outputLayerNeurons))
    for _ in range(num_epochs):

        hidden_layer_activation = np.dot(input_data, hidden_weights)
        hidden_layer_activation += hidden_bias
        hidden_layer_output = sigmoid(hidden_layer_activation)

        output_layer_activation = np.dot(hidden_layer_output, output_weights)
        output_layer_activation += output_bias
        predicted_output = sigmoid(output_layer_activation)

        error = output_data - predicted_output
        d_predicted_output = error * sigmoid_derivative(predicted_output)

        error_hidden_layer = d_predicted_output.dot(output_weights.T)
        d_hidden_layer = error_hidden_layer * sigmoid_derivative(hidden_layer_output)

        output_weights += hidden_layer_output.T.dot(d_predicted_output) * learning_rate
        output_bias += np.sum(d_predicted_output, axis=0, keepdims=True) * learning_rate
        hidden_weights += input_data.T.dot(d_hidden_layer) * learning_rate
        hidden_bias += np.sum(d_hidden_layer, axis=0, keepdims=True) * learning_rate

    return (
        hidden_bias,
        hidden_weights,
        output_bias,
        output_weights,
        predicted_output,
    )


# ZAD 5
def task_5(input_data, output_data, learning_rate, num_epochs):
    inputLayerNeurons, hiddenLayerNeurons, outputLayerNeurons = 2, 3, 2
    hidden_weights = np.array([[0.1, -0.2], [0, 0.2], [0.3, -0.4]]).T
    hidden_bias = np.array([[0.1, 0.2, 0.5]])
    output_weights = np.array([[-0.4, 0.1, 0.6], [0.2, -0.1, -0.2]]).T
    output_bias = np.array([[-0.1, 0.6]])
    for _ in range(num_epochs):

        hidden_layer_activation = np.dot(input_data, hidden_weights)
        hidden_layer_activation += hidden_bias
        hidden_layer_output = sigmoid(hidden_layer_activation)

        output_layer_activation = np.dot(hidden_layer_output, output_weights)
        output_layer_activation += output_bias
        predicted_output = sigmoid(output_layer_activation)

        error = output_data - predicted_output
        d_predicted_output = error * sigmoid_derivative(predicted_output)

        error_hidden_layer = d_predicted_output.dot(output_weights.T)
        d_hidden_layer = error_hidden_layer * sigmoid_derivative(hidden_layer_output)

        output_weights += hidden_layer_output.T.dot(d_predicted_output) * learning_rate
        output_bias += np.sum(d_predicted_output, axis=0, keepdims=True) * learning_rate
        hidden_weights += input_data.T.dot(d_hidden_layer) * learning_rate
        hidden_bias += np.sum(d_hidden_layer, axis=0, keepdims=True) * learning_rate

    return (
        hidden_bias,
        hidden_weights.T,
        output_bias,
        output_weights.T,
        predicted_output,
    )


# ZAD1
input_data = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
output_data = np.array([0, 0, 0, 1])
weights_AND, bias_AND = perceptron_learn(input_data, output_data, 1, 100)
print("Wagi perceptronu dla funkcji AND:", weights_AND)
print("Bias perceptronu dla funkcji AND:", bias_AND)
print("\n")
# ZAD2
input_data_2 = np.array([[0], [1]])
output_data_2 = np.array([1, 0])
weights_NOT, bias_NOT = perceptron_learn(input_data_2, output_data_2, 0.1, 100)
print("Wagi perceptronu dla funkcji NOT:", weights_NOT)
print("Bias perceptronu dla funkcji NOT:", bias_NOT)
print("\n")
# ZAD3 na kartce

# ZAD4
input_data_3 = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
output_data_3 = np.array([[0], [1], [1], [0]])
(
    hidden_bias,
    hidden_weights,
    output_bias,
    output_weights,
    predicted_output,
) = backpropagation_algorithm_xor(input_data_3, output_data_3, 0.1, 10000)


print(
    "Bias warstwy ukrytej dla funkcji XOR używająć algorytmu propagacji wstecznej:",
    *hidden_bias,
)
print(
    "Wagi warstwy ukrytej dla funkcji XOR używająć algorytmu propagacji wstecznej:",
    *hidden_weights,
)
print(
    "Bias warstwy wyjściowej dla funkcji XOR używająć algorytmu propagacji wstecznej:",
    *output_bias,
)
print(
    "Wagi warstwy wyjściowej dla funkcji XOR używająć algorytmu propagacji wstecznej:",
    *output_weights,
)
print(
    "Przewidywany wynik dla funkcji XOR używająć algorytmu propagacji wstecznej:",
    *predicted_output,
)

# ZAD5

input_data_task_5 = np.array([[0.6, 0.1], [0.2, 0.3]])
output_data_task_5 = np.array([[1], [0]])
(
    hidden_bias_task_5,
    hidden_weights_task_5,
    output_bias_task_5,
    output_weights_task_5,
    predicted_output_task_5,
) = task_5(input_data_task_5, output_data_task_5, 0.1, 10000)
print("\n")
print(
    "Bias warstwy ukrytej dla ZAD5 używająć algorytmu propagacji wstecznej:",
    *hidden_bias_task_5,
)
print(
    "Wagi warstwy ukrytej dla ZAD5 używająć algorytmu propagacji wstecznej:",
    *hidden_weights_task_5,
)
print(
    "Bias warstwy wyjściowej dla ZAD5 używająć algorytmu propagacji wstecznej:",
    *output_bias_task_5,
)
print(
    "Wagi warstwy wyjściowej dla ZAD5 używająć algorytmu propagacji wstecznej:",
    *output_weights_task_5,
)
print(
    "Przewidywany wynik dla ZAD5 używająć algorytmu propagacji wstecznej:",
    *predicted_output_task_5,
)
