import pandas as pd
import numpy as np


def indiscernibility(attr, table):

    u_ind = {}
    attr_values = []

    for i in table.index:

        attr_values = []
        for j in attr:

            attr_values.append(table.loc[i, j])

        key = "".join(str(k) for k in (attr_values))

        if key in u_ind:
            u_ind[key].add(i)

        else:
            u_ind[key] = set()
            u_ind[key].add(i)

    return list(u_ind.values())


def lower_approximation(R, X):

    l_approx = set()

    for i in range(len(X)):
        for j in range(len(R)):

            if R[j].issubset(X[i]):
                l_approx.update(R[j])

    return l_approx


def gamma_measure(describing_attributes, attributes_to_be_described, U, table):

    f_ind = indiscernibility(describing_attributes, table)
    t_ind = indiscernibility(attributes_to_be_described, table)

    f_lapprox = lower_approximation(f_ind, t_ind)

    return len(f_lapprox) / len(U)


def quick_reduct(C, D, table):

    reduct = set()

    gamma_C = gamma_measure(C, D, table.index, table)
    gamma_R = 0

    while gamma_R < gamma_C:

        T = reduct

        for x in set(C) - reduct:

            feature = set()
            feature.add(x)

            new_red = reduct.union(feature)

            gamma_new_red = gamma_measure(new_red, D, table.index, table)
            gamma_T = gamma_measure(T, D, table.index, table)

            if gamma_new_red > gamma_T:

                T = reduct.union(feature)

        reduct = T

        gamma_R = gamma_measure(reduct, D, table.index, table)

    return reduct


fig1 = pd.read_csv("fig1.csv")
fig2 = pd.read_csv("fig2.csv")
print(quick_reduct({"a", "b", "c", "d"}, {"dec"}, fig1))
print(quick_reduct({"a1", "a2", "a3"}, {"dec"}, fig2))
