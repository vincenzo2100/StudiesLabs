import gradio as gr
import pandas as pd


def execute_query(number, file):
    df = pd.read_csv(file.name, sep=" ", header=None)
    df.fillna(0, inplace=True)
    row1 = df.head(int(number))
    data1 = f"Ilość obiektów {len(df)}"
    data2 = f"Ilość atrybutów {len(df.columns)}"

    data3 = f"Symbole klas decyzyjnych: {pd.unique(df.iloc[:, -1])}"
    data4 = f"Wielkoś klas decyzyjnych (liczby obiektów w klasach): {df.iloc[:,-1].value_counts()}"
    data5 = f"Minimalna wartość poszczególnych atrybutów {df.min()}"
    data6 = f"Maksymalna wartość poszczególnych atrybutów {df.max()}"
    data7 = df.describe()
    return (
        f"{data1} \n {data2} \n {data3} \n {data4} \n {data5} \n {data6} \n {data7}",
        row1,
    )


iface = gr.Interface(
    fn=execute_query,
    inputs=[
        gr.inputs.Number(label="Liczba wierszy"),
        gr.inputs.File(label="Wprowadź plik"),
    ],
    outputs=[
        gr.outputs.Textbox(label="Wynik"),
        gr.outputs.Dataframe(label="Wiersze", type="pandas"),
    ],
    theme="HuggingFace",
    title="Obsługa systemu decyzyjnego",
    description="Opis",
    article="Article",
)
iface.launch()
